<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Form Submission Result</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>
        /* Your CSS styles here */
    </style>
</head>
<body>
    <div class="container">
        <h1>Form Submission Result</h1>

        <p>Name: <?php echo e($data['name']); ?></p>
        <p>Gender: <?php echo e($data['gender']); ?></p>
        <p>Age: <?php echo e($data['age']); ?></p>
        <p>Weight (kg): <?php echo e($data['weight']); ?></p>
        <p>Height (meters): <?php echo e($data['height']); ?></p>

        <?php if(!empty($data['image'])): ?>
            <img src="<?php echo e(asset('uploads/' . $data['image'])); ?>" alt="Uploaded Image">
        <?php endif; ?>
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /Users/danindra/Documents/PBKK/form-app/resources/views/result.blade.php ENDPATH**/ ?>